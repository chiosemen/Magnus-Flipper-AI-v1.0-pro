# Magnus Flipper AI — Microsoft Foundry Build Setup

This package contains a complete cloud build system for Expo SDK 54 / React Native 0.81:

✔ Cloud iOS build
✔ Cloud Android build
✔ Expo EAS integration
✔ Dev Tunnel support
✔ Zero CocoaPods / Xcode local builds
✔ Automatic signing + CI

Copy the `.foundry` folder, `.github/workflows`, and the `mobile/` configs into your main project.

Then run:

    cd mobile
    npx eas login
    npx eas build:configure
    npx eas device:create

After this, Foundry + EAS handle ALL mobile builds.
