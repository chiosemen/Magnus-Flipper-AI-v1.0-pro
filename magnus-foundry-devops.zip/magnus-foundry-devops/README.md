# Magnus Flipper AI — Complete DevOps & Foundry Setup

This package contains a production-ready cloud build system with full DevOps automation for Expo SDK 54 / React Native 0.81:

✔ Cloud iOS & Android builds
✔ OTA (Over-The-Air) updates via Expo
✔ Crash reporting with Sentry
✔ Real-time monitoring & alerting
✔ Automated release tagging
✔ Zero local Xcode/CocoaPods requirements
✔ CI/CD automation via GitHub Actions

## 📦 What's Included

### Build Pipelines (.foundry/)
- `foundry.yaml` - Main Foundry configuration
- `ios-build.yaml` - iOS cloud build pipeline
- `android-build.yaml` - Android cloud build pipeline
- `tunnel.yaml` - Dev tunnel for remote development
- `ota-release.yaml` - OTA update pipeline
- `monitoring.yaml` - Health checks & monitoring
- `crash-reporting.yaml` - Sentry crash reporting setup

### CI/CD Workflows (.github/workflows/)
- `mobile-cloud-build.yml` - Automated builds on push
- `mobile-ota-release.yml` - OTA update releases
- `mobile-release-tags.yml` - Version tagging automation
- `mobile-monitoring-checks.yml` - Health & performance monitoring

### Mobile Configuration (mobile/)
- `eas.json` - Expo EAS build profiles
- `App.js` - Expo Router entry point
- `sentry.properties` - Sentry project configuration
- `sentry.expo.js` - Sentry runtime integration

## 🚀 Setup Instructions

### 1. Copy files to your project
```bash
cp -r .foundry /path/to/your/project/
cp -r .github/workflows /path/to/your/project/.github/
cp -r mobile/* /path/to/your/project/mobile/
```

### 2. Configure Expo EAS
```bash
cd mobile
npx eas login
npx eas build:configure
npx eas device:create
```

### 3. Set up Sentry (for crash reporting)
```bash
# Install Sentry
npm install --save @sentry/react-native sentry-expo

# Update sentry.properties with your credentials:
# - defaults.org = your-sentry-org
# - defaults.project = magnus-flipper-ai
# - auth.token = your-sentry-auth-token
```

### 4. Configure GitHub Secrets
Add these secrets to your GitHub repository:
- `EXPO_TOKEN` - Expo account token
- `SENTRY_AUTH_TOKEN` - Sentry authentication token
- `SENTRY_ORG` - Sentry organization slug
- `SENTRY_PROJECT` - Sentry project name
- `APPLE_ID` - Apple Developer ID (optional)
- `APPLE_APP_SPECIFIC_PASSWORD` - Apple app-specific password (optional)

### 5. Run your first build
```bash
# Cloud iOS build
npx eas build -p ios --profile development

# Cloud Android build
npx eas build -p android --profile development

# OTA update (no rebuild required)
npx eas update --branch preview
```

## 📊 Monitoring & Alerts

This setup includes:
- **Crash Reporting**: Automatic error tracking via Sentry
- **Performance Monitoring**: Track app performance metrics
- **Release Health**: Monitor adoption rates and crash-free sessions
- **Build Monitoring**: GitHub Actions notifications on build failures

## 🔄 OTA Updates

Deploy updates instantly without app store review:
```bash
# Production OTA
npx eas update --branch production --message "Bug fixes"

# Preview OTA
npx eas update --branch preview --message "New feature testing"
```

## 🏷️ Release Management

Automated version tagging on releases:
- Tags are created automatically on `main` branch merges
- Format: `mobile-v1.0.0`
- Triggers production builds and OTA updates

## 🔧 Advanced Configuration

### Custom Build Profiles
Edit `mobile/eas.json` to add custom build profiles:
```json
{
  "build": {
    "staging": {
      "distribution": "internal",
      "env": {
        "APP_ENV": "staging"
      }
    }
  }
}
```

### Monitoring Thresholds
Edit `.foundry/monitoring.yaml` to customize health checks and alerts.

## 🆘 Troubleshooting

### Build fails with "No bundle URL present"
- Ensure metro is running: `npx expo start`
- Clear cache: `npx expo start -c`

### Sentry not receiving events
- Verify `sentry.properties` credentials
- Check `SENTRY_AUTH_TOKEN` in GitHub secrets
- Ensure `sentry.expo.js` is imported in `App.js`

### OTA updates not appearing
- Check branch name matches EAS build profile
- Verify `expo-updates` is installed
- Ensure runtime version matches

## 📚 Resources

- [Expo EAS Build Docs](https://docs.expo.dev/build/introduction/)
- [Expo Updates (OTA) Docs](https://docs.expo.dev/eas-update/introduction/)
- [Sentry React Native Docs](https://docs.sentry.io/platforms/react-native/)
- [Microsoft Foundry Docs](https://foundry.microsoft.com/docs)

## 🎯 Next Steps

1. Set up staging and production EAS build profiles
2. Configure Sentry alerts and notification rules
3. Set up branch protection and required status checks
4. Enable automated dependency updates with Dependabot
5. Add E2E tests to CI pipeline

---

**Built with Microsoft Foundry + Expo EAS**
Zero local builds. Maximum automation.
