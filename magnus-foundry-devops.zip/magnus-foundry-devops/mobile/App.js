import { ExpoRoot } from "expo-router";
import * as Sentry from "@sentry/react-native";

// Initialize Sentry BEFORE rendering the app
// Only initialize in production builds
if (!__DEV__) {
  Sentry.init({
    dsn: "YOUR_SENTRY_DSN_HERE",
    debug: false, // Set to true for debugging Sentry itself
    environment: process.env.APP_ENV || "development",
    enableInExpoDevelopment: false,
    tracesSampleRate: 1.0, // Adjust this for production (0.1-0.2 recommended)
    _experiments: {
      profilesSampleRate: 1.0, // Profiling sample rate
    },
    integrations: [
      new Sentry.ReactNativeTracing({
        routingInstrumentation: new Sentry.ReactNavigationInstrumentation(),
      }),
    ],
  });
}

function App() {
  const ctx = require.context("./app");
  return <ExpoRoot context={ctx} />;
}

// Wrap the app with Sentry's error boundary
// This will catch any errors and send them to Sentry
export default __DEV__ ? App : Sentry.wrap(App);
