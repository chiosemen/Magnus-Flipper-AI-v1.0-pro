/**
 * Sentry Configuration for Expo
 *
 * This file configures Sentry integration for the Magnus Flipper AI mobile app.
 * It should be imported in your app.json or app.config.js
 */

module.exports = {
  organization: "YOUR_SENTRY_ORG",
  project: "magnus-flipper-ai",

  // Auth token is loaded from environment variable for security
  // NEVER hardcode the token here
  authToken: process.env.SENTRY_AUTH_TOKEN,

  // Disable auto-upload during development
  disableAutoUpload: process.env.APP_ENV === "development",

  // Source map configuration
  setCommits: {
    auto: true,
    ignoreMissing: true,
  },

  // Deploy configuration
  deploy: {
    env: process.env.APP_ENV || "development",
  },

  // Distribution identifier (unique for each build)
  dist: process.env.EAS_BUILD_ID,

  // Release name format
  release: `mobile@${process.env.npm_package_version}+${process.env.EAS_BUILD_ID}`,
};
